<?php $__env->startSection('meta'); ?>
    <title>Preshama - Manage users</title>
    <link href="<?php echo e(asset('assets/css/elements/miscellaneous.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/css/elements/breadcrumb.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-action'); ?>
    <h3>Add customer</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <!--  BEGIN CONTENT PART  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="account-settings-container layout-top-spacing">

                <div class="account-content">
                    <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form id="work-experience" class="section work-experience" method="post" action="<?php echo e(route('customers.store')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="info">
                                        <h5 class="">Fill Sales Rep details</h5>
                                        <div class="row">
                                            
                                            <div class="col-md-8 mx-auto">

                                                <div class="work-section">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <input type="hidden" name="user_type" value="SALES_REP">
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree3">First name</label>
                                                                        <input type="text" class="form-control mb-4" id="degree3" placeholder="First name" value="<?php echo e(old('firstname')); ?>" name="fname" required="required">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree4">Last name</label>
                                                                        <input type="text" class="form-control mb-4" id="degree4" placeholder="Surname" value="<?php echo e(old('lastname')); ?>" name="lname" required="required">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree3">Email address</label>
                                                                        <input type="email" class="form-control mb-4" id="degree3" placeholder="Email address" value="<?php echo e(old('email')); ?>" name="email">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree4">Mobile</label>
                                                                        <input type="tel" class="form-control mb-4" id="degree4" placeholder="Mobile number" value="<?php echo e(old('mobile')); ?>" name="mobileno">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                        <label for="degree4">Pin</label>
                                                        <input type="password" class="form-control mb-4" id="degree4" placeholder="Pin" name="pin" required="required" maxlength="5">
                                                    </div>
                                                        <div class="col-md-12">
                                                            <button type="submit" class="btn btn-primary mt-3">Save details</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--  END CONTENT PART  -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lawrence/preshama/resources/views/admin/customers/create-app-user.blade.php ENDPATH**/ ?>