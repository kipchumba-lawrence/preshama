<?php $__env->startSection('meta'); ?>
    <title>Preshama - Manage app users</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/datatables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/table/datatable/dt-global_style.css')); ?>">
    <link href="<?php echo e(asset('assets/css/apps/invoice-list.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-action'); ?>
    <h3>Manage app users</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <!--  BEGIN CONTENT PART  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="row layout-top-spacing" id="cancel-row">

                <div class="col-xl-12 col-lg-12 col-sm-12  layout-spacing">
                    <h3>Customers</h3>
                    <div class="widget-content widget-content-area br-6">
                        <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="dt-buttons">
                            <a class="dt-button btn btn-primary btn-sm" href="<?php echo e(route('customers.create')); ?>"
                                tabindex="0" aria-controls="invoice-list"><span>Add
                                    New</span>

                            </a> 
                            <a class="mx-2 dt-button btn btn-primary btn-sm" href="<?php echo e(route('customers.update_customer_credit')); ?>"
                                tabindex="0" aria-controls="invoice-list"><span >Refresh credit Scores</span>

                            </a>
                        </div>
                        <table id="zero-config" class="table dt-table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>First name</th>
                                    <th>Surname</th>
                                    <th>Username</th>
                                    <th>User Type</th>
                                    <th class="no-content">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($user->user_id != Auth::user()->user_id): ?>
                                        <tr>
                                            <td><?php echo e($user->first_name); ?></td>
                                            <td><?php echo e($user->surname); ?></td>
                                            <td><?php echo e($user->username); ?></td>
                                            <td><?php echo e($user->user_type); ?></td>
                                            <td>

                                                <a id="edit-<?php echo e($user->user_id); ?>" href="#" data-toggle="modal"
                                                    data-target="#editUser"
                                                    onclick="editUser(<?php echo e(json_encode($user)); ?>);return false;">Edit</a> |


                                                <form id="delete-form-<?php echo e($user->user_id); ?>"
                                                    action="<?php echo e(route('customers.destroy', $user->user_id)); ?>"
                                                    style="display: none;" method="post">
                                                    <?php echo e(@csrf_field()); ?>

                                                    <?php echo e(@method_field('DELETE')); ?>

                                                </form>
                                                <a data-toggle="tooltip" href="#"
                                                    onclick="
                                                       if(confirm('Are you sure you want to delete this user?'))
                                                       {event.preventDefault();
                                                       document.getElementById('delete-form-<?php echo e($user->user_id); ?>').submit();
                                                       }
                                                       else{
                                                       event.preventDefault();
                                                       }
                                                       ">Delete</a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>First name</th>
                                    <th>Surname</th>
                                    <th>Username</th>
                                    <th>User Type</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!--  END CONTENT PART  -->

    <div id="editUser" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <div class="card-title mb-3">Edit User</div>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="col-md-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <form role="form" method="post"
                                    action="<?php echo e(route('customers.update.appUser', $user->user_id)); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="app_user_id" id="app_user_id">
                                    <div class="row">
                                        <div class="col-md-12 form-group mb-3">
                                            <label for="user_type">User role</label>
                                            <select class="form-control" id="user_type" name="user_type"
                                                required="required">
                                                <option value="">Select role</option>
                                                <option value="SALES_REP">SALES REP</option>
                                                <option value="USER">USER</option>
                                            </select>
                                            <?php $__errorArgs = ['user_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="fname">First name</label>
                                            <input type="text" class="form-control" placeholder="First name"
                                                id="fname" name="fname" value="<?php echo e(old('fname')); ?>">
                                            <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="lname">Last name</label>
                                            <input type="text" class="form-control" placeholder="Surname" id="lname"
                                                name="lname" value="<?php echo e(old('lname')); ?>">
                                            <?php $__errorArgs = ['lname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control" placeholder="Email" id="email"
                                                name="email" value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="mobileno">Mobile</label>
                                            <input type="tel" class="form-control" placeholder="Mobile Number"
                                                id="mobileno" name="mobileno" value="<?php echo e(old('mobileno')); ?>">
                                            <?php $__errorArgs = ['mobileno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="customerno">Customer number</label>
                                            <input type="text" class="form-control" id="customerno" name="customerno"
                                                placeholder="Customer Number" value="<?php echo e(old('customerno')); ?>">
                                            <?php $__errorArgs = ['customerno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 form-group mb-3">
                                            <label for="pin">Pin</label>
                                            <input type="password" class="form-control" placeholder="Pin" id="pin"
                                                name="pin" value="<?php echo e(old('pin')); ?>">
                                            <?php $__errorArgs = ['pin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="alert alert-danger"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>

                                    </br>

                                    <button type="submit" class="btn btn-block btn-primary">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footerSection'); ?>
    <script src="<?php echo e(asset('plugins/table/datatable/datatables.js')); ?>"></script>

    <script type="text/javascript">
        function editUser(user) {
            $("#app_user_id").val(user.user_id);
            $("#user_type").val(user.user_type);
            $('#fname').val(user.first_name);
            $('#lname').val(user.surname);
            $('#email').val(user.email);
            $('#mobileno').val(user.mobileno);
            $('#customerno').val(user.customer_no);
            $('#pin').val(user.pin);
        }
    </script>

    <script>
        $('#zero-config').DataTable({
            "dom": "<'dt--top-section'<'row'<'col-12 col-sm-6 d-flex justify-content-sm-start justify-content-center'l><'col-12 col-sm-6 d-flex justify-content-sm-end justify-content-center mt-sm-0 mt-3'f>>>" +
                "<'table-responsive'tr>" +
                "<'dt--bottom-section d-sm-flex justify-content-sm-between text-center'<'dt--pages-count  mb-sm-0 mb-3'i><'dt--pagination'p>>",
            "oLanguage": {
                "oPaginate": {
                    "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>',
                    "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>'
                },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
                "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
            "lengthMenu": [7, 10, 20, 50],
            "pageLength": 7
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lawrence/preshama/resources/views/admin/customers/show.blade.php ENDPATH**/ ?>