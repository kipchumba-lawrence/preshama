<?php $__env->startSection('meta'); ?>
    <title>Preshama - Manage users</title>
    <link href="<?php echo e(asset('assets/css/elements/miscellaneous.css')); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset('assets/css/elements/breadcrumb.css')); ?>" rel="stylesheet" type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-action'); ?>
    <h3>Add customer</h3>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main-content'); ?>
    <!--  BEGIN CONTENT PART  -->
    <div id="content" class="main-content">
        <div class="layout-px-spacing">

            <div class="account-settings-container layout-top-spacing">

                <div class="account-content">
                    <div class="scrollspy-example" data-spy="scroll" data-target="#account-settings-scroll" data-offset="-100">
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 layout-spacing">
                                <?php echo $__env->make('includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form id="work-experience" class="section work-experience" method="post" action="<?php echo e(route('customers.store')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="info">
                                        <h5 class="">Fill in customer details</h5>
                                        <div class="row">
                                            <div class="col-md-12 text-right mb-5">
                                                <a href="<?php echo e(route('customers.index')); ?>" id="add-work-exp" class="btn btn-secondary">Back</a>
                                            </div>
                                            <div class="col-md-8 mx-auto">

                                                <div class="work-section">
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label for="degree2">Customer Name/s</label>
                                                                <input type="text" class="form-control mb-4" id="degree2" placeholder="Add company name or customer names" value="<?php echo e(old('name')); ?>" required="required" name="name">
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree3">Customer number</label>
                                                                        <input type="text" class="form-control mb-4" id="degree3" placeholder="Customer number" value="<?php echo e(old('customer_number')); ?>" name="customer_number" required="required">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree4">Customer code</label>
                                                                        <input type="text" class="form-control mb-4" id="degree4" placeholder="Customer code" value="<?php echo e(old('customer_code')); ?>" name="customer_code">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree3">Email address</label>
                                                                        <input type="email" class="form-control mb-4" id="degree3" placeholder="Email address" value="<?php echo e(old('email')); ?>" name="email">
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label for="degree4">Mobile</label>
                                                                        <input type="tel" class="form-control mb-4" id="degree4" placeholder="Mobile number" value="<?php echo e(old('mobile')); ?>" name="mobile">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>


                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label>Credit limit and credit exposure</label>
                                                                        <div class="row">
                                                                            <div class="col-md-6">
                                                                                <input type="number" class="form-control mb-4" id="degree4" placeholder="Credit limit" value="<?php echo e(old('credit_limit')); ?>" name="credit_limit">
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <input type="number" class="form-control mb-4" id="degree4" placeholder="Credit exposure" value="<?php echo e(old('credit_exposure')); ?>" name="credit_exposure">
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <div class="form-group">
                                                                        <label>Sales manager and route</label>

                                                                        <div class="row">
                                                                            <div class="col-md-6 mb-4">
                                                                                <select class="form-control" id="eiend-in1" name="salesmanager" required="required" >
                                                                                    <option value="">Select sales rep</option>
                                                                                    <?php $__currentLoopData = $sales_managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales_manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($sales_manager->user_id); ?>"><?php echo e($sales_manager->first_name); ?> <?php echo e($sales_manager->surname); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>

                                                                            <div class="col-md-6">
                                                                                <select class="form-control" id="eiend-in1" name="route" required="required" >
                                                                                    <option value="">Select route...</option>
                                                                                    <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <option value="<?php echo e($route->route_id); ?>"><?php echo e($route->route_name); ?></option>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                </select>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="col-md-12">
                                                            <button type="submit" class="btn btn-primary mt-3">Save details</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!--  END CONTENT PART  -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/lawrence/preshama/resources/views/admin/customers/create.blade.php ENDPATH**/ ?>