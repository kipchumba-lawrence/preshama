<?php $__env->startSection('meta'); ?>
    <?php echo $__env->yieldSection(); ?>

<title><?php echo e(config('app.name', 'Log in')); ?></title>

<!-- Scripts -->
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>"/>
<!-- BEGIN GLOBAL MANDATORY STYLES -->
<link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
<link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('assets/css/plugins.css')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('css/authentication/form-2.css')); ?>" rel="stylesheet" type="text/css" />
<!-- END GLOBAL MANDATORY STYLES -->
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/theme-checkbox-radio.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/forms/switches.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/elements/alert.css')); ?>">


<?php /**PATH /Users/lawrence/preshama/resources/views/auth/layouts/head.blade.php ENDPATH**/ ?>