<!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
<script src="<?php echo e(asset('assets/js/libs/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- END GLOBAL MANDATORY SCRIPTS -->
<script src="<?php echo e(asset('assets/js/authentication/form-2.js')); ?>"></script>
<?php $__env->startSection('footerSection'); ?>
<?php echo $__env->yieldSection(); ?>
<?php /**PATH /Users/lawrence/preshama/resources/views/auth/layouts/footer.blade.php ENDPATH**/ ?>