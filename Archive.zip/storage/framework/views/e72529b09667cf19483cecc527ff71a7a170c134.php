<!doctype html>
<html lang="en">
    <head>
        <?php echo $__env->make('auth/layouts/head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="form">
        <?php $__env->startSection('main-content'); ?>
            <?php echo $__env->yieldSection(); ?>
        <?php echo $__env->make('auth/layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html>
<?php /**PATH /Users/lawrence/preshama/resources/views/auth/layouts/auth.blade.php ENDPATH**/ ?>