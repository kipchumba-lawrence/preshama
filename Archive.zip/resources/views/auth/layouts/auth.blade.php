<!doctype html>
<html lang="en">
    <head>
        @include('auth/layouts/head')
    </head>
    <body class="form">
        @section('main-content')
            @show
        @include('auth/layouts/footer')
    </body>
</html>
